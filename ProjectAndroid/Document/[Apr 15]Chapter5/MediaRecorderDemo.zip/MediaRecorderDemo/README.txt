Simple sound recorder
