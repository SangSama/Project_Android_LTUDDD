OpenGL graphics
